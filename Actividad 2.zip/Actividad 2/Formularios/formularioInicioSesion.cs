﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class formularioInicioSesion : Form
    {
        public formularioInicioSesion()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void botonInicioDeSesion_Click(object sender, EventArgs e)
        {
            if (txtInicioDeSesion.Text == "")
            {
                MessageBox.Show("Debe ingresar una contraseña");
            }
            else if (txtInicioDeSesion.Text == "123456")
            {
                formularioPrincipal formularioPrincipal = new formularioPrincipal();
                formularioPrincipal.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Contraseña incorrecta, intente de nuevo por favor");
                txtInicioDeSesion.Clear();
            }

        }
    }
}
