﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class formularioPrincipal : Form
    {
        public formularioPrincipal()
        {
            InitializeComponent();
        }

        private void saludosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.formularioSaludo formularioSaludo = new Formularios.formularioSaludo();
            formularioSaludo.Show();
        }
        private void pestanaDatosPersonales_Click(object sender, EventArgs e)
        {
            Formularios.formularioDatosPersonales formularioDatosPersonales = new Formularios.formularioDatosPersonales();
            formularioDatosPersonales.Show();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pestanaOperacionesBasicas_Click(object sender, EventArgs e)
        {
            Formularios.formularioOperacionesBasicas formularioOperacionesBasicas = new Formularios.formularioOperacionesBasicas();
            formularioOperacionesBasicas.Show();
        }

        private void pestanaSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
