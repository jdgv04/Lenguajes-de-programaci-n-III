﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class formularioSaludo : Form
    {
        public formularioSaludo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clases.claseSaludo saludo = new Clases.claseSaludo();
            string saludar = saludo.Saludar(txtNombre.Text);
            MessageBox.Show(saludar);
        }

        private void botonRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
