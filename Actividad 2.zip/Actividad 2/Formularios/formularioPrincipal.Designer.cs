﻿namespace Actividad_2
{
    partial class formularioPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formularioPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pestanaSaludo = new System.Windows.Forms.ToolStripMenuItem();
            this.pestanaDatosPersonales = new System.Windows.Forms.ToolStripMenuItem();
            this.pestanaOperacionesBasicas = new System.Windows.Forms.ToolStripMenuItem();
            this.pestanaSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pestanaSaludo,
            this.pestanaDatosPersonales,
            this.pestanaOperacionesBasicas,
            this.pestanaSalir});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pestanaSaludo
            // 
            this.pestanaSaludo.Name = "pestanaSaludo";
            this.pestanaSaludo.Size = new System.Drawing.Size(55, 20);
            this.pestanaSaludo.Text = "Saludo";
            this.pestanaSaludo.Click += new System.EventHandler(this.saludosToolStripMenuItem_Click);
            // 
            // pestanaDatosPersonales
            // 
            this.pestanaDatosPersonales.Name = "pestanaDatosPersonales";
            this.pestanaDatosPersonales.Size = new System.Drawing.Size(108, 20);
            this.pestanaDatosPersonales.Text = "Datos Personales";
            this.pestanaDatosPersonales.Click += new System.EventHandler(this.pestanaDatosPersonales_Click);
            // 
            // pestanaOperacionesBasicas
            // 
            this.pestanaOperacionesBasicas.Name = "pestanaOperacionesBasicas";
            this.pestanaOperacionesBasicas.Size = new System.Drawing.Size(126, 20);
            this.pestanaOperacionesBasicas.Text = "Operaciones Basicas";
            this.pestanaOperacionesBasicas.Click += new System.EventHandler(this.pestanaOperacionesBasicas_Click);
            // 
            // pestanaSalir
            // 
            this.pestanaSalir.Name = "pestanaSalir";
            this.pestanaSalir.Size = new System.Drawing.Size(41, 20);
            this.pestanaSalir.Text = "Salir";
            this.pestanaSalir.Click += new System.EventHandler(this.pestanaSalir_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(321, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "¡Bienvenido!";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Actividad_2.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(275, 80);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(244, 213);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // formularioPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "formularioPrincipal";
            this.Text = "Menú";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pestanaSaludo;
        private System.Windows.Forms.ToolStripMenuItem pestanaDatosPersonales;
        private System.Windows.Forms.ToolStripMenuItem pestanaOperacionesBasicas;
        private System.Windows.Forms.ToolStripMenuItem pestanaSalir;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}

