﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD
{
    public partial class formularioPrincipal : Form
    {
        public formularioPrincipal()
        {
            InitializeComponent();
        }

        private void mensajeDeBienvenidaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bienvenido a la tienda en linea ZAPATERIA UMI donde prodrá encontrar todo lo que usted necesita y si no lo encuentra se lo conseguimos.\nSomos su mejor opción hoy y siempre");
        }

        private void quiénesSomosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("¿Quiénes somos?\nSomos una empresa mexicana, que trata de apoyar al comercio mexicano, todos nuestros productos son 100% mexicanos, porque\ncreemos en nosotros y porque sabemos que podemos");
        }

        private void misiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("MISIÓN\nNuestra misión es darnos a conocer a nivel nacional y lograr el objetivo de que todos los mexicanos utilicen productos mexicanos, que abramos los ojos y veamos que no porque el producto sea de otro país, signifique que es mejor.");
        }

        private void visiónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("VISIÓN\nNuestra visión es que una vez que nos encontremos a nivel nacional, buscaremos el mercado internacional y llevaremos el nombre de nuestro producto, de nuestro país, a todo el mundo para que sepa de lo que somos capaces");
        }

        private void damasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.formularioProductosDama formularioProductosDama = new Formularios.formularioProductosDama();
            formularioProductosDama.Show();
        }

        private void caballerosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.formularioProductosHombre formularioProductosHombre = new Formularios.formularioProductosHombre();
            formularioProductosHombre.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.formularioContraseña formularioContraseña = new Formularios.formularioContraseña();
            formularioContraseña.Show();
        }

        private void proveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.formularioRegistrarProveedor formularioRegistrarProveedor = new Formularios.formularioRegistrarProveedor();
            formularioRegistrarProveedor.Show();
        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.formularioRegistrarProductos formularioRegistrarProductos = new Formularios.formularioRegistrarProductos();
            formularioRegistrarProductos.Show();
        }

        private void registroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void comprasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.formularioCompras formularioCompras = new Formularios.formularioCompras();
            formularioCompras.Show();
        }
    }
}
