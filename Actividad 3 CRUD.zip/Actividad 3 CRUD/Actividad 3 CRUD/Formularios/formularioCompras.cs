﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Formularios
{
    public partial class formularioCompras : Form
    {
        public formularioCompras()
        {
            InitializeComponent();
        }

        private void botonAgregarCompra_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO COMPRAS (dniCliente, codProducto) VALUES ('" + textoDniCliente.Text + "', '" + textoCodigoProducto.Text + "')", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoDniCliente.Clear();
                textoCodigoProducto.Clear();
                textoIdCompra.Clear();
                MessageBox.Show("Se ha agregado una nueva compra de manera exitosa.");
            }
        }

        private void botonModificarCompra_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE COMPRAS SET dniCliente = '" + textoDniCliente.Text + "', codProducto = '" + textoCodigoProducto.Text + "' where idCompra = '" + textoIdCompra.Text + "'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoDniCliente.Clear();
                textoCodigoProducto.Clear();
                textoIdCompra.Clear();
                MessageBox.Show("Se ha modificado una compra de manera exitosa.");
            }
        }

        private void botonEliminarCompra_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from COMPRAS where idCompra = '" + textoIdCompra.Text + "'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoDniCliente.Clear();
                textoCodigoProducto.Clear();
                textoIdCompra.Clear();
                MessageBox.Show("Se ha eliminado una compra de manera exitosa.");
            }
        }

        private void botonMostrarCompra_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM COMPRAS", conexion);
                da.SelectCommand.CommandType = CommandType.Text;
                conexion.Open();
                da.Fill(dt);
                dataGridViewCompra.DataSource = dt;
            }
        }

        private void botonRegresarCompra_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
