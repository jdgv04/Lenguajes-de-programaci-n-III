﻿namespace Actividad_3_CRUD.Formularios
{
    partial class formularioRegistrarProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formularioRegistrarProveedor));
            this.dataGridViewClientes = new System.Windows.Forms.DataGridView();
            this.botonRegresarCliente = new System.Windows.Forms.Button();
            this.botonMostrarCliente = new System.Windows.Forms.Button();
            this.botonEliminarCliente = new System.Windows.Forms.Button();
            this.botonModificarCliente = new System.Windows.Forms.Button();
            this.botonAgregarCliente = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textoDireccionProveedor = new System.Windows.Forms.TextBox();
            this.textoNombreProveedor = new System.Windows.Forms.TextBox();
            this.textoNifProveedor = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewClientes
            // 
            this.dataGridViewClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClientes.Location = new System.Drawing.Point(17, 263);
            this.dataGridViewClientes.Name = "dataGridViewClientes";
            this.dataGridViewClientes.Size = new System.Drawing.Size(772, 177);
            this.dataGridViewClientes.TabIndex = 33;
            // 
            // botonRegresarCliente
            // 
            this.botonRegresarCliente.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.botonRegresarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonRegresarCliente.Location = new System.Drawing.Point(607, 200);
            this.botonRegresarCliente.Name = "botonRegresarCliente";
            this.botonRegresarCliente.Size = new System.Drawing.Size(139, 36);
            this.botonRegresarCliente.TabIndex = 32;
            this.botonRegresarCliente.Text = "REGRESAR";
            this.botonRegresarCliente.UseVisualStyleBackColor = false;
            this.botonRegresarCliente.Click += new System.EventHandler(this.botonRegresarCliente_Click);
            // 
            // botonMostrarCliente
            // 
            this.botonMostrarCliente.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.botonMostrarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonMostrarCliente.Location = new System.Drawing.Point(545, 150);
            this.botonMostrarCliente.Name = "botonMostrarCliente";
            this.botonMostrarCliente.Size = new System.Drawing.Size(244, 41);
            this.botonMostrarCliente.TabIndex = 31;
            this.botonMostrarCliente.Text = "MOSTRAR";
            this.botonMostrarCliente.UseVisualStyleBackColor = false;
            this.botonMostrarCliente.Click += new System.EventHandler(this.botonMostrarCliente_Click);
            // 
            // botonEliminarCliente
            // 
            this.botonEliminarCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.botonEliminarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonEliminarCliente.Location = new System.Drawing.Point(684, 99);
            this.botonEliminarCliente.Name = "botonEliminarCliente";
            this.botonEliminarCliente.Size = new System.Drawing.Size(105, 36);
            this.botonEliminarCliente.TabIndex = 30;
            this.botonEliminarCliente.Text = "ELIMINAR";
            this.botonEliminarCliente.UseVisualStyleBackColor = false;
            this.botonEliminarCliente.Click += new System.EventHandler(this.botonEliminarCliente_Click);
            // 
            // botonModificarCliente
            // 
            this.botonModificarCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.botonModificarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonModificarCliente.Location = new System.Drawing.Point(545, 99);
            this.botonModificarCliente.Name = "botonModificarCliente";
            this.botonModificarCliente.Size = new System.Drawing.Size(133, 37);
            this.botonModificarCliente.TabIndex = 29;
            this.botonModificarCliente.Text = "MODIFICAR";
            this.botonModificarCliente.UseVisualStyleBackColor = false;
            this.botonModificarCliente.Click += new System.EventHandler(this.botonModificarCliente_Click);
            // 
            // botonAgregarCliente
            // 
            this.botonAgregarCliente.BackColor = System.Drawing.Color.Green;
            this.botonAgregarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonAgregarCliente.Location = new System.Drawing.Point(545, 47);
            this.botonAgregarCliente.Name = "botonAgregarCliente";
            this.botonAgregarCliente.Size = new System.Drawing.Size(244, 41);
            this.botonAgregarCliente.TabIndex = 28;
            this.botonAgregarCliente.Text = "AGREGAR";
            this.botonAgregarCliente.UseVisualStyleBackColor = false;
            this.botonAgregarCliente.Click += new System.EventHandler(this.botonAgregarCliente_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(225, 25);
            this.label6.TabIndex = 27;
            this.label6.Text = "Datos del proveedor";
            // 
            // textoDireccionProveedor
            // 
            this.textoDireccionProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoDireccionProveedor.Location = new System.Drawing.Point(239, 122);
            this.textoDireccionProveedor.Name = "textoDireccionProveedor";
            this.textoDireccionProveedor.Size = new System.Drawing.Size(281, 31);
            this.textoDireccionProveedor.TabIndex = 24;
            // 
            // textoNombreProveedor
            // 
            this.textoNombreProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoNombreProveedor.Location = new System.Drawing.Point(239, 81);
            this.textoNombreProveedor.Name = "textoNombreProveedor";
            this.textoNombreProveedor.Size = new System.Drawing.Size(281, 31);
            this.textoNombreProveedor.TabIndex = 23;
            // 
            // textoNifProveedor
            // 
            this.textoNifProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoNifProveedor.Location = new System.Drawing.Point(239, 44);
            this.textoNifProveedor.Name = "textoNifProveedor";
            this.textoNifProveedor.Size = new System.Drawing.Size(281, 31);
            this.textoNifProveedor.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 25);
            this.label3.TabIndex = 19;
            this.label3.Text = "Dirección";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 25);
            this.label2.TabIndex = 18;
            this.label2.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 25);
            this.label1.TabIndex = 17;
            this.label1.Text = "NIF";
            // 
            // formularioRegistrarProveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridViewClientes);
            this.Controls.Add(this.botonRegresarCliente);
            this.Controls.Add(this.botonMostrarCliente);
            this.Controls.Add(this.botonEliminarCliente);
            this.Controls.Add(this.botonModificarCliente);
            this.Controls.Add(this.botonAgregarCliente);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textoDireccionProveedor);
            this.Controls.Add(this.textoNombreProveedor);
            this.Controls.Add(this.textoNifProveedor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formularioRegistrarProveedor";
            this.Text = "Registrar Proveedores";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewClientes;
        private System.Windows.Forms.Button botonRegresarCliente;
        private System.Windows.Forms.Button botonMostrarCliente;
        private System.Windows.Forms.Button botonEliminarCliente;
        private System.Windows.Forms.Button botonModificarCliente;
        private System.Windows.Forms.Button botonAgregarCliente;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textoDireccionProveedor;
        private System.Windows.Forms.TextBox textoNombreProveedor;
        private System.Windows.Forms.TextBox textoNifProveedor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}