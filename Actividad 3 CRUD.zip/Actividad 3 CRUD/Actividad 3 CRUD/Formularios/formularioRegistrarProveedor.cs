﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Formularios
{
    public partial class formularioRegistrarProveedor : Form
    {
        public formularioRegistrarProveedor()
        {
            InitializeComponent();
        }

        private void botonAgregarCliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO PROVEEDORES (nif, nombre, direccion) VALUES ('" + textoNifProveedor.Text + "', '" + textoNombreProveedor.Text + "', '" + textoDireccionProveedor.Text + "')", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoNifProveedor.Clear();
                textoNombreProveedor.Clear();
                textoDireccionProveedor.Clear();
                MessageBox.Show("Se ha agregado un nuevo proveedor de manera exitosa.");
            }
        }

        private void botonModificarCliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE PROVEEDORES SET nif = '" + textoNifProveedor.Text + "', nombre = '" + textoNombreProveedor.Text + "', direccion = '" + textoDireccionProveedor.Text + "'  Where nif = '" + textoNifProveedor.Text + "'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoNifProveedor.Clear();
                textoNombreProveedor.Clear();
                textoDireccionProveedor.Clear();
                MessageBox.Show("Se ha modificado el proveedor de manera exitosa.");
            }
        }

        private void botonEliminarCliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from PROVEEDORES where nif = '" + textoNifProveedor.Text + "'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoNifProveedor.Clear();
                textoNombreProveedor.Clear();
                textoDireccionProveedor.Clear();
                MessageBox.Show("Se ha eliminado el proveedor de manera exitosa.");
            }
        }

        private void botonMostrarCliente_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM PROVEEDORES", conexion);
                da.SelectCommand.CommandType = CommandType.Text;
                conexion.Open();
                da.Fill(dt);
                dataGridViewClientes.DataSource = dt;
            }
        }

        private void botonRegresarCliente_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
