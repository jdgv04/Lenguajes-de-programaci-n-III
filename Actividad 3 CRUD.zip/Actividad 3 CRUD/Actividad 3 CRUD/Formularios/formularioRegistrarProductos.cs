﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Formularios
{
    public partial class formularioRegistrarProductos : Form
    {
        public formularioRegistrarProductos()
        {
            InitializeComponent();
        }

        private void botonAgregarProducto_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO PRODUCTOS (codigo, nombre, precio, nifProveedor) VALUES ('" + textoCodigoProducto.Text + "', '" + textoNombreProducto.Text + "', '" + textoPrecioProducto.Text + "', '" + textoNifProveedorProducto.Text + "')", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoCodigoProducto.Clear();
                textoNombreProducto.Clear();
                textoPrecioProducto.Clear();
                textoNifProveedorProducto.Clear();
                MessageBox.Show("Se ha agregado un nuevo producto de manera exitosa.");
            }
        }

        private void botonModificarProducto_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE PRODUCTOS SET codigo = '" + textoCodigoProducto.Text + "', nombre = '" + textoNombreProducto.Text + "', precio = '" + textoPrecioProducto.Text + "', nifProveedor = '" + textoNifProveedorProducto.Text + "' Where codigo = '" + textoCodigoProducto.Text + "'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoCodigoProducto.Clear();
                textoNombreProducto.Clear();
                textoPrecioProducto.Clear();
                textoNifProveedorProducto.Clear();
                MessageBox.Show("Se ha modificado el producto de manera exitosa.");
            }
        }

        private void botonEliminarProducto_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from PRODUCTOS where codigo = '" + textoCodigoProducto.Text + "'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoCodigoProducto.Clear();
                textoNombreProducto.Clear();
                textoPrecioProducto.Clear();
                textoNifProveedorProducto.Clear();
                MessageBox.Show("Se ha eliminado el producto de manera exitosa.");
            }
        }

        private void botonMostrarProducto_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM PRODUCTOS", conexion);
                da.SelectCommand.CommandType = CommandType.Text;
                conexion.Open();
                da.Fill(dt);
                dataGridViewProducto.DataSource = dt;
            }
        }

        private void botonRegresarProducto_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
