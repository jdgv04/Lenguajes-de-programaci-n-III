﻿namespace Actividad_3_CRUD.Formularios
{
    partial class formularioRegistrarProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formularioRegistrarProductos));
            this.dataGridViewProducto = new System.Windows.Forms.DataGridView();
            this.botonRegresarProducto = new System.Windows.Forms.Button();
            this.botonMostrarProducto = new System.Windows.Forms.Button();
            this.botonEliminarProducto = new System.Windows.Forms.Button();
            this.botonModificarProducto = new System.Windows.Forms.Button();
            this.botonAgregarProducto = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textoNifProveedorProducto = new System.Windows.Forms.TextBox();
            this.textoPrecioProducto = new System.Windows.Forms.TextBox();
            this.textoNombreProducto = new System.Windows.Forms.TextBox();
            this.textoCodigoProducto = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducto)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewProducto
            // 
            this.dataGridViewProducto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProducto.Location = new System.Drawing.Point(17, 263);
            this.dataGridViewProducto.Name = "dataGridViewProducto";
            this.dataGridViewProducto.Size = new System.Drawing.Size(772, 177);
            this.dataGridViewProducto.TabIndex = 33;
            // 
            // botonRegresarProducto
            // 
            this.botonRegresarProducto.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.botonRegresarProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonRegresarProducto.Location = new System.Drawing.Point(607, 200);
            this.botonRegresarProducto.Name = "botonRegresarProducto";
            this.botonRegresarProducto.Size = new System.Drawing.Size(139, 36);
            this.botonRegresarProducto.TabIndex = 32;
            this.botonRegresarProducto.Text = "REGRESAR";
            this.botonRegresarProducto.UseVisualStyleBackColor = false;
            this.botonRegresarProducto.Click += new System.EventHandler(this.botonRegresarProducto_Click);
            // 
            // botonMostrarProducto
            // 
            this.botonMostrarProducto.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.botonMostrarProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonMostrarProducto.Location = new System.Drawing.Point(545, 150);
            this.botonMostrarProducto.Name = "botonMostrarProducto";
            this.botonMostrarProducto.Size = new System.Drawing.Size(244, 41);
            this.botonMostrarProducto.TabIndex = 31;
            this.botonMostrarProducto.Text = "MOSTRAR";
            this.botonMostrarProducto.UseVisualStyleBackColor = false;
            this.botonMostrarProducto.Click += new System.EventHandler(this.botonMostrarProducto_Click);
            // 
            // botonEliminarProducto
            // 
            this.botonEliminarProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.botonEliminarProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonEliminarProducto.Location = new System.Drawing.Point(684, 99);
            this.botonEliminarProducto.Name = "botonEliminarProducto";
            this.botonEliminarProducto.Size = new System.Drawing.Size(105, 36);
            this.botonEliminarProducto.TabIndex = 30;
            this.botonEliminarProducto.Text = "ELIMINAR";
            this.botonEliminarProducto.UseVisualStyleBackColor = false;
            this.botonEliminarProducto.Click += new System.EventHandler(this.botonEliminarProducto_Click);
            // 
            // botonModificarProducto
            // 
            this.botonModificarProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.botonModificarProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonModificarProducto.Location = new System.Drawing.Point(545, 99);
            this.botonModificarProducto.Name = "botonModificarProducto";
            this.botonModificarProducto.Size = new System.Drawing.Size(133, 37);
            this.botonModificarProducto.TabIndex = 29;
            this.botonModificarProducto.Text = "MODIFICAR";
            this.botonModificarProducto.UseVisualStyleBackColor = false;
            this.botonModificarProducto.Click += new System.EventHandler(this.botonModificarProducto_Click);
            // 
            // botonAgregarProducto
            // 
            this.botonAgregarProducto.BackColor = System.Drawing.Color.Green;
            this.botonAgregarProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonAgregarProducto.Location = new System.Drawing.Point(545, 47);
            this.botonAgregarProducto.Name = "botonAgregarProducto";
            this.botonAgregarProducto.Size = new System.Drawing.Size(244, 41);
            this.botonAgregarProducto.TabIndex = 28;
            this.botonAgregarProducto.Text = "AGREGAR";
            this.botonAgregarProducto.UseVisualStyleBackColor = false;
            this.botonAgregarProducto.Click += new System.EventHandler(this.botonAgregarProducto_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(211, 25);
            this.label6.TabIndex = 27;
            this.label6.Text = "Datos del producto";
            // 
            // textoNifProveedorProducto
            // 
            this.textoNifProveedorProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoNifProveedorProducto.Location = new System.Drawing.Point(239, 162);
            this.textoNifProveedorProducto.Name = "textoNifProveedorProducto";
            this.textoNifProveedorProducto.Size = new System.Drawing.Size(281, 31);
            this.textoNifProveedorProducto.TabIndex = 25;
            // 
            // textoPrecioProducto
            // 
            this.textoPrecioProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoPrecioProducto.Location = new System.Drawing.Point(239, 122);
            this.textoPrecioProducto.Name = "textoPrecioProducto";
            this.textoPrecioProducto.Size = new System.Drawing.Size(281, 31);
            this.textoPrecioProducto.TabIndex = 24;
            // 
            // textoNombreProducto
            // 
            this.textoNombreProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoNombreProducto.Location = new System.Drawing.Point(239, 81);
            this.textoNombreProducto.Name = "textoNombreProducto";
            this.textoNombreProducto.Size = new System.Drawing.Size(281, 31);
            this.textoNombreProducto.TabIndex = 23;
            // 
            // textoCodigoProducto
            // 
            this.textoCodigoProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoCodigoProducto.Location = new System.Drawing.Point(239, 44);
            this.textoCodigoProducto.Name = "textoCodigoProducto";
            this.textoCodigoProducto.Size = new System.Drawing.Size(281, 31);
            this.textoCodigoProducto.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 25);
            this.label4.TabIndex = 20;
            this.label4.Text = "NIF Proveedor";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 25);
            this.label3.TabIndex = 19;
            this.label3.Text = "Precio";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 25);
            this.label2.TabIndex = 18;
            this.label2.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 25);
            this.label1.TabIndex = 17;
            this.label1.Text = "Código";
            // 
            // formularioRegistrarProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridViewProducto);
            this.Controls.Add(this.botonRegresarProducto);
            this.Controls.Add(this.botonMostrarProducto);
            this.Controls.Add(this.botonEliminarProducto);
            this.Controls.Add(this.botonModificarProducto);
            this.Controls.Add(this.botonAgregarProducto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textoNifProveedorProducto);
            this.Controls.Add(this.textoPrecioProducto);
            this.Controls.Add(this.textoNombreProducto);
            this.Controls.Add(this.textoCodigoProducto);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formularioRegistrarProductos";
            this.Text = "Registrar Productos";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewProducto;
        private System.Windows.Forms.Button botonRegresarProducto;
        private System.Windows.Forms.Button botonMostrarProducto;
        private System.Windows.Forms.Button botonEliminarProducto;
        private System.Windows.Forms.Button botonModificarProducto;
        private System.Windows.Forms.Button botonAgregarProducto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textoNifProveedorProducto;
        private System.Windows.Forms.TextBox textoPrecioProducto;
        private System.Windows.Forms.TextBox textoNombreProducto;
        private System.Windows.Forms.TextBox textoCodigoProducto;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}