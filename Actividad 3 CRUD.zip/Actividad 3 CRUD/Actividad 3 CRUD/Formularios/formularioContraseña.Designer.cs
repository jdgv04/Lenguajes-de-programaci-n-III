﻿namespace Actividad_3_CRUD.Formularios
{
    partial class formularioContraseña
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formularioContraseña));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textoContraseña = new System.Windows.Forms.TextBox();
            this.botonContraseña = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Actividad_3_CRUD.Properties.Resources.png_transparent_password_safe_android_encapsulated_postscript_web_browser_android_android_password_password_safe;
            this.pictureBox1.Location = new System.Drawing.Point(112, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(322, 48);
            this.label1.TabIndex = 1;
            this.label1.Text = "Para ingresar a esta opción necesitas\r\ningresar una contraseña valida";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textoContraseña
            // 
            this.textoContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoContraseña.Location = new System.Drawing.Point(54, 219);
            this.textoContraseña.Name = "textoContraseña";
            this.textoContraseña.PasswordChar = '*';
            this.textoContraseña.Size = new System.Drawing.Size(230, 31);
            this.textoContraseña.TabIndex = 2;
            // 
            // botonContraseña
            // 
            this.botonContraseña.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.botonContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonContraseña.Location = new System.Drawing.Point(125, 273);
            this.botonContraseña.Name = "botonContraseña";
            this.botonContraseña.Size = new System.Drawing.Size(98, 35);
            this.botonContraseña.TabIndex = 3;
            this.botonContraseña.Text = "Ingresar";
            this.botonContraseña.UseVisualStyleBackColor = false;
            this.botonContraseña.Click += new System.EventHandler(this.botonContraseña_Click);
            // 
            // formularioContraseña
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 363);
            this.Controls.Add(this.botonContraseña);
            this.Controls.Add(this.textoContraseña);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formularioContraseña";
            this.Text = "Acceso Controlado";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textoContraseña;
        private System.Windows.Forms.Button botonContraseña;
    }
}