﻿namespace Actividad_3_CRUD.Formularios
{
    partial class formularioRegistrarCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formularioRegistrarCliente));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textoDni = new System.Windows.Forms.TextBox();
            this.textoNombre = new System.Windows.Forms.TextBox();
            this.textoApellidos = new System.Windows.Forms.TextBox();
            this.textoFechaNacimiento = new System.Windows.Forms.TextBox();
            this.textoTelefono = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.botonAgregarCliente = new System.Windows.Forms.Button();
            this.botonModificarCliente = new System.Windows.Forms.Button();
            this.botonEliminarCliente = new System.Windows.Forms.Button();
            this.botonMostrarCliente = new System.Windows.Forms.Button();
            this.botonRegresarCliente = new System.Windows.Forms.Button();
            this.dataGridViewClientes = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "DNI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellidos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(215, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Fecha de Nacimiento";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Teléfono";
            // 
            // textoDni
            // 
            this.textoDni.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoDni.Location = new System.Drawing.Point(238, 42);
            this.textoDni.Name = "textoDni";
            this.textoDni.Size = new System.Drawing.Size(281, 31);
            this.textoDni.TabIndex = 5;
            // 
            // textoNombre
            // 
            this.textoNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoNombre.Location = new System.Drawing.Point(238, 79);
            this.textoNombre.Name = "textoNombre";
            this.textoNombre.Size = new System.Drawing.Size(281, 31);
            this.textoNombre.TabIndex = 6;
            // 
            // textoApellidos
            // 
            this.textoApellidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoApellidos.Location = new System.Drawing.Point(238, 120);
            this.textoApellidos.Name = "textoApellidos";
            this.textoApellidos.Size = new System.Drawing.Size(281, 31);
            this.textoApellidos.TabIndex = 7;
            // 
            // textoFechaNacimiento
            // 
            this.textoFechaNacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoFechaNacimiento.Location = new System.Drawing.Point(238, 160);
            this.textoFechaNacimiento.Name = "textoFechaNacimiento";
            this.textoFechaNacimiento.Size = new System.Drawing.Size(281, 31);
            this.textoFechaNacimiento.TabIndex = 8;
            // 
            // textoTelefono
            // 
            this.textoTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoTelefono.Location = new System.Drawing.Point(238, 201);
            this.textoTelefono.Name = "textoTelefono";
            this.textoTelefono.Size = new System.Drawing.Size(281, 31);
            this.textoTelefono.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(196, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "Datos personales";
            // 
            // botonAgregarCliente
            // 
            this.botonAgregarCliente.BackColor = System.Drawing.Color.Green;
            this.botonAgregarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonAgregarCliente.Location = new System.Drawing.Point(544, 45);
            this.botonAgregarCliente.Name = "botonAgregarCliente";
            this.botonAgregarCliente.Size = new System.Drawing.Size(244, 41);
            this.botonAgregarCliente.TabIndex = 11;
            this.botonAgregarCliente.Text = "AGREGAR";
            this.botonAgregarCliente.UseVisualStyleBackColor = false;
            this.botonAgregarCliente.Click += new System.EventHandler(this.botonAgregarCliente_Click);
            // 
            // botonModificarCliente
            // 
            this.botonModificarCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.botonModificarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonModificarCliente.Location = new System.Drawing.Point(544, 97);
            this.botonModificarCliente.Name = "botonModificarCliente";
            this.botonModificarCliente.Size = new System.Drawing.Size(133, 37);
            this.botonModificarCliente.TabIndex = 12;
            this.botonModificarCliente.Text = "MODIFICAR";
            this.botonModificarCliente.UseVisualStyleBackColor = false;
            this.botonModificarCliente.Click += new System.EventHandler(this.botonModificarCliente_Click);
            // 
            // botonEliminarCliente
            // 
            this.botonEliminarCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.botonEliminarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonEliminarCliente.Location = new System.Drawing.Point(683, 97);
            this.botonEliminarCliente.Name = "botonEliminarCliente";
            this.botonEliminarCliente.Size = new System.Drawing.Size(105, 36);
            this.botonEliminarCliente.TabIndex = 13;
            this.botonEliminarCliente.Text = "ELIMINAR";
            this.botonEliminarCliente.UseVisualStyleBackColor = false;
            this.botonEliminarCliente.Click += new System.EventHandler(this.botonEliminarCliente_Click);
            // 
            // botonMostrarCliente
            // 
            this.botonMostrarCliente.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.botonMostrarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonMostrarCliente.Location = new System.Drawing.Point(544, 148);
            this.botonMostrarCliente.Name = "botonMostrarCliente";
            this.botonMostrarCliente.Size = new System.Drawing.Size(244, 41);
            this.botonMostrarCliente.TabIndex = 14;
            this.botonMostrarCliente.Text = "MOSTRAR";
            this.botonMostrarCliente.UseVisualStyleBackColor = false;
            this.botonMostrarCliente.Click += new System.EventHandler(this.botonMostrarCliente_Click);
            // 
            // botonRegresarCliente
            // 
            this.botonRegresarCliente.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.botonRegresarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonRegresarCliente.Location = new System.Drawing.Point(606, 198);
            this.botonRegresarCliente.Name = "botonRegresarCliente";
            this.botonRegresarCliente.Size = new System.Drawing.Size(139, 36);
            this.botonRegresarCliente.TabIndex = 15;
            this.botonRegresarCliente.Text = "REGRESAR";
            this.botonRegresarCliente.UseVisualStyleBackColor = false;
            this.botonRegresarCliente.Click += new System.EventHandler(this.botonRegresarCliente_Click);
            // 
            // dataGridViewClientes
            // 
            this.dataGridViewClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClientes.Location = new System.Drawing.Point(16, 261);
            this.dataGridViewClientes.Name = "dataGridViewClientes";
            this.dataGridViewClientes.Size = new System.Drawing.Size(772, 177);
            this.dataGridViewClientes.TabIndex = 16;
            // 
            // formularioRegistrarCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridViewClientes);
            this.Controls.Add(this.botonRegresarCliente);
            this.Controls.Add(this.botonMostrarCliente);
            this.Controls.Add(this.botonEliminarCliente);
            this.Controls.Add(this.botonModificarCliente);
            this.Controls.Add(this.botonAgregarCliente);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textoTelefono);
            this.Controls.Add(this.textoFechaNacimiento);
            this.Controls.Add(this.textoApellidos);
            this.Controls.Add(this.textoNombre);
            this.Controls.Add(this.textoDni);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formularioRegistrarCliente";
            this.Text = "Registrar Clientes";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClientes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textoDni;
        private System.Windows.Forms.TextBox textoNombre;
        private System.Windows.Forms.TextBox textoApellidos;
        private System.Windows.Forms.TextBox textoFechaNacimiento;
        private System.Windows.Forms.TextBox textoTelefono;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button botonAgregarCliente;
        private System.Windows.Forms.Button botonModificarCliente;
        private System.Windows.Forms.Button botonEliminarCliente;
        private System.Windows.Forms.Button botonMostrarCliente;
        private System.Windows.Forms.Button botonRegresarCliente;
        private System.Windows.Forms.DataGridView dataGridViewClientes;
    }
}