﻿namespace Actividad_3_CRUD.Formularios
{
    partial class formularioCompras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formularioCompras));
            this.dataGridViewCompra = new System.Windows.Forms.DataGridView();
            this.botonRegresarCompra = new System.Windows.Forms.Button();
            this.botonMostrarCompra = new System.Windows.Forms.Button();
            this.botonEliminarCompra = new System.Windows.Forms.Button();
            this.botonModificarCompra = new System.Windows.Forms.Button();
            this.botonAgregarCompra = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textoCodigoProducto = new System.Windows.Forms.TextBox();
            this.textoDniCliente = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textoIdCompra = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCompra)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewCompra
            // 
            this.dataGridViewCompra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCompra.Location = new System.Drawing.Point(17, 263);
            this.dataGridViewCompra.Name = "dataGridViewCompra";
            this.dataGridViewCompra.Size = new System.Drawing.Size(772, 177);
            this.dataGridViewCompra.TabIndex = 46;
            // 
            // botonRegresarCompra
            // 
            this.botonRegresarCompra.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.botonRegresarCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonRegresarCompra.Location = new System.Drawing.Point(607, 200);
            this.botonRegresarCompra.Name = "botonRegresarCompra";
            this.botonRegresarCompra.Size = new System.Drawing.Size(139, 36);
            this.botonRegresarCompra.TabIndex = 45;
            this.botonRegresarCompra.Text = "REGRESAR";
            this.botonRegresarCompra.UseVisualStyleBackColor = false;
            this.botonRegresarCompra.Click += new System.EventHandler(this.botonRegresarCompra_Click);
            // 
            // botonMostrarCompra
            // 
            this.botonMostrarCompra.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.botonMostrarCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonMostrarCompra.Location = new System.Drawing.Point(545, 150);
            this.botonMostrarCompra.Name = "botonMostrarCompra";
            this.botonMostrarCompra.Size = new System.Drawing.Size(244, 41);
            this.botonMostrarCompra.TabIndex = 44;
            this.botonMostrarCompra.Text = "MOSTRAR";
            this.botonMostrarCompra.UseVisualStyleBackColor = false;
            this.botonMostrarCompra.Click += new System.EventHandler(this.botonMostrarCompra_Click);
            // 
            // botonEliminarCompra
            // 
            this.botonEliminarCompra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.botonEliminarCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonEliminarCompra.Location = new System.Drawing.Point(684, 99);
            this.botonEliminarCompra.Name = "botonEliminarCompra";
            this.botonEliminarCompra.Size = new System.Drawing.Size(105, 36);
            this.botonEliminarCompra.TabIndex = 43;
            this.botonEliminarCompra.Text = "ELIMINAR";
            this.botonEliminarCompra.UseVisualStyleBackColor = false;
            this.botonEliminarCompra.Click += new System.EventHandler(this.botonEliminarCompra_Click);
            // 
            // botonModificarCompra
            // 
            this.botonModificarCompra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.botonModificarCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonModificarCompra.Location = new System.Drawing.Point(545, 99);
            this.botonModificarCompra.Name = "botonModificarCompra";
            this.botonModificarCompra.Size = new System.Drawing.Size(133, 37);
            this.botonModificarCompra.TabIndex = 42;
            this.botonModificarCompra.Text = "MODIFICAR";
            this.botonModificarCompra.UseVisualStyleBackColor = false;
            this.botonModificarCompra.Click += new System.EventHandler(this.botonModificarCompra_Click);
            // 
            // botonAgregarCompra
            // 
            this.botonAgregarCompra.BackColor = System.Drawing.Color.Green;
            this.botonAgregarCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonAgregarCompra.Location = new System.Drawing.Point(545, 47);
            this.botonAgregarCompra.Name = "botonAgregarCompra";
            this.botonAgregarCompra.Size = new System.Drawing.Size(244, 41);
            this.botonAgregarCompra.TabIndex = 41;
            this.botonAgregarCompra.Text = "AGREGAR";
            this.botonAgregarCompra.UseVisualStyleBackColor = false;
            this.botonAgregarCompra.Click += new System.EventHandler(this.botonAgregarCompra_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(220, 25);
            this.label6.TabIndex = 40;
            this.label6.Text = "Datos de la Compra";
            // 
            // textoCodigoProducto
            // 
            this.textoCodigoProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoCodigoProducto.Location = new System.Drawing.Point(239, 81);
            this.textoCodigoProducto.Name = "textoCodigoProducto";
            this.textoCodigoProducto.Size = new System.Drawing.Size(281, 31);
            this.textoCodigoProducto.TabIndex = 38;
            // 
            // textoDniCliente
            // 
            this.textoDniCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoDniCliente.Location = new System.Drawing.Point(239, 44);
            this.textoDniCliente.Name = "textoDniCliente";
            this.textoDniCliente.Size = new System.Drawing.Size(281, 31);
            this.textoDniCliente.TabIndex = 37;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 25);
            this.label2.TabIndex = 35;
            this.label2.Text = "Código del Producto";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 25);
            this.label1.TabIndex = 34;
            this.label1.Text = "DNI del Cliente";
            // 
            // textoIdCompra
            // 
            this.textoIdCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textoIdCompra.Location = new System.Drawing.Point(239, 160);
            this.textoIdCompra.Name = "textoIdCompra";
            this.textoIdCompra.Size = new System.Drawing.Size(281, 31);
            this.textoIdCompra.TabIndex = 48;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(213, 50);
            this.label3.TabIndex = 47;
            this.label3.Text = "Id de la Compra\r\n(Modificar o eliminar)";
            // 
            // formularioCompras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textoIdCompra);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridViewCompra);
            this.Controls.Add(this.botonRegresarCompra);
            this.Controls.Add(this.botonMostrarCompra);
            this.Controls.Add(this.botonEliminarCompra);
            this.Controls.Add(this.botonModificarCompra);
            this.Controls.Add(this.botonAgregarCompra);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textoCodigoProducto);
            this.Controls.Add(this.textoDniCliente);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formularioCompras";
            this.Text = "Registrar Compras";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCompra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewCompra;
        private System.Windows.Forms.Button botonRegresarCompra;
        private System.Windows.Forms.Button botonMostrarCompra;
        private System.Windows.Forms.Button botonEliminarCompra;
        private System.Windows.Forms.Button botonModificarCompra;
        private System.Windows.Forms.Button botonAgregarCompra;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textoCodigoProducto;
        private System.Windows.Forms.TextBox textoDniCliente;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textoIdCompra;
        private System.Windows.Forms.Label label3;
    }
}