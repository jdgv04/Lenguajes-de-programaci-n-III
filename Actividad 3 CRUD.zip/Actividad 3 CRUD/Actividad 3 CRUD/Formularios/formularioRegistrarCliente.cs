﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Formularios
{
    public partial class formularioRegistrarCliente : Form
    {
        public formularioRegistrarCliente()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void botonMostrarCliente_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter da = new SqlDataAdapter ("SELECT * FROM CLIENTES", conexion);
                da.SelectCommand.CommandType = CommandType.Text;
                conexion.Open();
                da.Fill(dt);
                dataGridViewClientes.DataSource = dt;
            }
        }

        private void botonAgregarCliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False")) 
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO CLIENTES (dni, nombre, apellidos, fechaNac, telefono) VALUES ('"+textoDni.Text+"', '"+textoNombre.Text+"', '"+textoApellidos.Text+"', '"+textoFechaNacimiento.Text+"', '"+textoTelefono.Text+"')", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoDni.Clear();
                textoNombre.Clear();
                textoApellidos.Clear();
                textoFechaNacimiento.Clear();
                textoTelefono.Clear();
                MessageBox.Show("Se ha agregado un nuevo cliente de manera exitosa.");
            }
            

        }

        private void botonModificarCliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE CLIENTES SET dni = '" + textoDni.Text + "', nombre = '" + textoNombre.Text + "', apellidos = '" + textoApellidos.Text + "', fechaNac = '" + textoFechaNacimiento.Text + "', telefono = '" + textoTelefono.Text + "'  Where dni = '"+textoDni.Text+"'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoDni.Clear();
                textoNombre.Clear();
                textoApellidos.Clear();
                textoFechaNacimiento.Clear();
                textoTelefono.Clear();
                MessageBox.Show("Se han modificado los datos del cliente de manera exitosa.");
            }
        }

        private void botonEliminarCliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-VV30AGH\\SQLEXPRESS;Initial Catalog=TiendaDepartamental;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE from CLIENTES where dni = '" + textoDni.Text + "'", conexion);
                cmd.CommandType = CommandType.Text;
                conexion.Open();
                cmd.ExecuteNonQuery();
                textoDni.Clear();
                textoNombre.Clear();
                textoApellidos.Clear();
                textoFechaNacimiento.Clear();
                textoTelefono.Clear();
                MessageBox.Show("Se ha eliminado el cliente de manera exitosa.");
            }
        }

        private void botonRegresarCliente_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
